# The Working Tribe — Static Frontend Delivery

A fully pre-rendered static build of the TWT marketing site. Everything in
`site/` is plain HTML, CSS, JavaScript, fonts and images. **No Node.js
process, no Next.js server and no runtime environment variables are
required.** Any static host will serve it.

| | |
| --- | --- |
| **Build date** | 2026-11-13 |
| **Built from** | Next.js 16.4.5 (App Router) · React 19.3.0 · TypeScript 5 · Tailwind CSS v4 |
| **Build command** | `npm run build:static` |
| **Package contents** | `site/` (129 files, ~23 MB) + this file |
| **Pages** | 7 routes + a 404 page |

---

## 1. What is in `site/`

```
site/
├─ index.html                 /
├─ about/index.html           /about/
├─ why-twt/index.html         /why-twt/
├─ careers/index.html         /careers/
├─ training-programs/index.html
├─ industries/index.html
├─ contact/index.html
├─ 404.html                   error page (also at 404/index.html)
├─ _next/                     CSS, JS chunks, self-hosted fonts  (~1.2 MB)
├─ images/                    photography                        (~16 MB)
├─ decor/                     SVG background patterns            (~248 KB)
├─ favicon.ico · icon.svg · apple-icon.png · icon-192.png · icon-512.png
├─ manifest.webmanifest       PWA manifest
└─ *.txt                      React Server Component payloads — see §6
```

**Do not delete the `.txt` files.** They are not documentation. They are the
payloads the App Router fetches for client-side page transitions. Without
them every internal link falls back to a full page reload.

---

## 2. Deploying

### The short version

Upload **the contents of `site/`** — not the `site/` folder itself — into your
hosting document root (`public_html`, `www`, `htdocs`, the S3 bucket root, …).
`index.html` must end up at the root of the domain.

```
public_html/
├─ index.html      ← must be here, not in public_html/site/
├─ about/
├─ _next/
└─ ...
```

That is the whole deployment. There is no build step on the server, no
`npm install`, and no process to keep running.

### Clean URLs

The export was built with `trailingSlash: true`, so every page is an
`index.html` inside its own directory (`about/index.html`, not `about.html`).
This is deliberate: **directory-index resolution is default behaviour on every
mainstream web server**, so `/about/` resolves with no rewrite rules at all.

What you may still want to configure:

**Apache** — redirect the no-slash form and set the error page. Create
`.htaccess` in the document root:

```apache
DirectorySlash On
DirectoryIndex index.html
ErrorDocument 404 /404.html

# Long-cache fingerprinted assets; never cache HTML.
<IfModule mod_headers.c>
  <FilesMatch "\.(js|css|woff2|png|jpe?g|svg|ico)$">
    Header set Cache-Control "public, max-age=31536000, immutable"
  </FilesMatch>
  <FilesMatch "\.(html|txt|webmanifest)$">
    Header set Cache-Control "public, max-age=0, must-revalidate"
  </FilesMatch>
</IfModule>
```

> Caution: `_next/static/**` filenames are content-hashed and safe to cache
> forever. `images/**` and `decor/**` are **not** hashed — if you replace a
> photo you must purge the cache or rename the file.

**Nginx**

```nginx
root /var/www/twt;
index index.html;

location / {
    try_files $uri $uri/ $uri.html =404;
}

error_page 404 /404.html;

location ~* ^/_next/static/ {
    add_header Cache-Control "public, max-age=31536000, immutable";
}
location ~* \.(html|txt|webmanifest)$ {
    add_header Cache-Control "public, max-age=0, must-revalidate";
}
```

**IIS** — `web.config` in the root:

```xml
<configuration>
  <system.webServer>
    <defaultDocument><files><add value="index.html" /></files></defaultDocument>
    <httpErrors errorMode="Custom">
      <remove statusCode="404" />
      <error statusCode="404" path="/404.html" responseMode="ExecuteURL" />
    </httpErrors>
    <staticContent>
      <remove fileExtension=".webmanifest" />
      <mimeMap fileExtension=".webmanifest" mimeType="application/manifest+json" />
    </staticContent>
  </system.webServer>
</configuration>
```

**Netlify / Cloudflare Pages / GitHub Pages / S3 + CloudFront** — point the
publish directory at the uploaded files. Directory indexes and `404.html` are
picked up automatically. On S3, set the index document to `index.html` and the
error document to `404.html`.

### MIME types

Confirm the server sends `application/manifest+json` for `.webmanifest` and
`font/woff2` for `.woff2`. Most modern servers do; older IIS and some shared
hosts do not, and the font will silently fall back to Arial.

### Testing locally before upload

```bash
cd site
python -m http.server 8080      # or: npx serve .
```

Then open <http://localhost:8080>. Do **not** judge the build by opening
`index.html` with `file://` — absolute asset paths (`/_next/...`) cannot
resolve from the filesystem, and the page will look unstyled. That is a
`file://` limitation, not a build fault.

---

## 3. Routes

### Live — included in this build

| Route | Page |
| --- | --- |
| `/` | Home |
| `/about/` | About Us |
| `/why-twt/` | Why TWT |
| `/careers/` | Careers (incl. application form UI) |
| `/training-programs/` | Training Programs (incl. 4 registration overlays) |
| `/industries/` | Industries |
| `/contact/` | Contact Us (incl. enquiry form UI) |
| `/404.html` | Not found |

### Not built yet — links exist, pages do not

These are referenced by the header, footer and in-page links and will return
your server's 404 until the pages are built. **This is intentional** — the
project rule is that a navigation link points at its final URL rather than a
placeholder page being invented to make it resolve.

| Route | Referenced from |
| --- | --- |
| `/services/` | header "Services", Why TWT |
| `/services/training-capacity-building/` | header, footer, Industries |
| `/services/advisory-management-consulting/` | header, footer, Industries |
| `/services/global-solutions/` | header, footer, Industries |
| `/services/tribe-capital/` | header, footer, Contact hero |
| `/faq/` | footer |
| `/newsletters/` | footer |
| `/privacy-policy/` | footer legal row |
| `/terms-of-use/` | footer legal row |
| `/cookie-settings/` | footer legal row |

> **Expected console noise.** The App Router prefetches links that scroll into
> view, so these ten routes produce `404` entries in the browser Network tab
> on pages that link to them. Nothing breaks — the prefetch simply fails and
> the link still navigates (to your 404 page). It resolves itself as each page
> is built. This behaviour is identical on a Node-hosted deployment; it is not
> caused by the static export.

### Excluded on purpose

`/dev/tokens` is a development-only design-token specimen. It calls
`notFound()` in production builds, so it was removed from this package
entirely — leaving it in would have served a "page not found" body under an
HTTP **200**. The route is simply absent, so your server returns a real 404.

---

## 4. Forms — none of them submit

**Every form on this site is front-end only. There is no backend, no API, no
email delivery and no file storage.** Nothing is persisted anywhere and
nothing is sent to anyone.

| Form | Where | State |
| --- | --- | --- |
| Request a consultation | popup, from every "Request a consultation" CTA | Validates. Does not submit. |
| Training registration | `/training-programs/`, `/` — 4 season overlays | Validates. Does not submit. |
| Careers application (incl. CV upload) | `/careers/` | Validates. Does not submit. The chosen file never leaves the browser. |

What actually happens on a valid submit: the transport stub returns
`not-configured`, and the form shows an honest "not sent" notice while keeping
everything the visitor typed. **No success message is ever shown**, by design —
a "Thank you" that no one received would be worse than an error.

The acknowledgement screens exist in code (`ApplicationReceived`) but are
unreachable until a real backend returns success. They can be reviewed in
Storybook.

### What a backend has to provide

Still an open client decision — Google Forms, Google Sheets, Apps Script and a
custom endpoint have all been discussed, none chosen. Whoever implements it
needs to supply:

1. An HTTPS endpoint per form (or one with a type discriminator).
2. File upload handling for the CV (accepted formats and max size are **not
   yet confirmed** by the client — today only a 0-byte file is rejected).
3. Auto-reply email wording, sender address and routing — **all unspecified**.
4. Spam protection. There is none.

The three integration points are isolated and typed:
`src/lib/submit-consultation.ts`, `src/lib/submit-application.ts` and the
registration overlay's handler. Each returns a typed result; swapping the stub
for a real `fetch` is the whole job on the frontend side.

**A static host cannot run any of this.** It serves files only. The endpoint
must live elsewhere (serverless function, form service, or your own API), and
CORS must allow the site's origin.

---

## 5. Known limitations

**Images are unoptimized.** Static export has no `/_next/image` endpoint, so
`images.unoptimized` is set and every `<Image>` serves the original file.
Layout, `sizes` and `fill` behaviour are unchanged, but ~16 MB of JPEGs ship
at full weight — `/industries/` alone pulls 21 images. **This is the first
thing to improve.** Options: pre-compress to WebP/AVIF at the source, put a
CDN with image transforms in front, or deploy to a host with a built-in image
pipeline. No code change is needed for a CDN.

**Image content is not final.** Several pages still show AI-generated concept
imagery pending replacement with licensed stock. Image credit records
(`src/content/credits.ts`) are still owed.

**Unconfirmed content still on the page.** Two international phone numbers are
displayed but deliberately **not** clickable, because their international
format is disputed and guessing a country code would mean inventing client
data:

- **Asia** `+1 33 7024 0773` — country code unconfirmed
- **Africa** `+233 598 277 323` — conflicts with a previously approved
  `+233 59 822 7323`

Only the USA number (`+1 315 832 0551`) is a working `tel:` link. Both other
rows show a "Call" affordance that is intentionally inert until the client
confirms the numbers; they are not links and are not keyboard-focusable.
Training programme **venue** and **date/time** show "To be announced" for the
same reason.

**No analytics, no cookie banner, no consent management.** Nothing is tracked
and no third-party script is loaded. If analytics are added, the
`/cookie-settings/` page (not built) becomes a legal requirement in several
jurisdictions.

**No sitemap.xml or robots.txt.** Neither was in scope. Add them before
launch.

**Metadata.** Page titles and descriptions are set. Open Graph / Twitter card
images are not.

### Next.js features that cannot work on static hosting

None are used by this site, but for whoever extends it:

| Feature | Static host |
| --- | --- |
| API routes / Route Handlers (dynamic) | ✗ no server |
| Server Actions | ✗ |
| Middleware | ✗ |
| ISR / on-demand revalidation | ✗ |
| `next/image` optimizer | ✗ (hence `unoptimized`) |
| Dynamic routes without `generateStaticParams` | ✗ |
| Draft mode, `cookies()`, `headers()` | ✗ |

The current site uses **none** of these, which is why it exports cleanly.
Adding any of them means moving to a Node host (or Vercel) and running
`npm run build` + `npm start` instead.

---

## 6. Build notes for the next developer

### How the static build is wired

The normal workflow is untouched. `npm run dev`, `npm run build` and
`npm start` behave exactly as before, image optimizer included.

- `npm run build:static` runs `scripts/build-static.mjs`, which sets
  `TWT_OUTPUT=export` and calls `next build`.
- `next.config.ts` adds `output: "export"`, `images.unoptimized` and
  `trailingSlash` **only** when that variable is set.
- Written as a Node script rather than an inline env var so it works
  identically on Windows, macOS and Linux with no `cross-env` dependency.

### Two changes were needed to make the export pass

Both are additive. Nothing was removed or disabled to force a green build.

1. **`src/app/manifest.ts` now declares `export const dynamic = "force-static"`.**
   The manifest is a Route Handler; `output: "export"` refuses to collect one
   that has not declared itself static. It always was static — nothing in it
   reads the request.

2. **`scripts/build-static.mjs` writes RSC payload aliases after the export.**
   This works around a bug in **Next.js 16.4.5**: the export writes each
   route's payload into a *directory*

   ```
   out/about/__next.about/__PAGE__.txt
   ```

   while the client runtime requests it as a *flat file*

   ```
   /about/__next.about.__PAGE__.txt
   ```

   Nothing serves that path, so every prefetch 404s and **every internal link
   falls back to a full page reload**. The script copies each payload to the
   name the runtime asks for — it adds files, deletes nothing, and touches no
   application code. Verified before and after: with the aliases, clicking an
   internal link is a client-side transition with no reload.

   **Delete `flattenRscPayloads()` once Next.js emits the flat name itself**,
   then re-check the Network tab for `__next.*.txt` 404s.

### Verification performed on this exact build

Served from `out/` by a plain static HTTP server — no Next.js dev server in
the loop — and exercised in Chrome at **1440px, 768px and 375px** across all
7 routes (21 combinations):

- All 7 routes return HTTP 200; an unknown path returns a real 404.
- 0 broken images, 0 JavaScript errors, 0 unexpected failed requests.
- Fonts load from `_next/static/media` and render in Sofia Sans Semi
  Condensed (not a fallback).
- Consultation popup opens from every CTA, traps focus, locks page scroll and
  restores it on `Esc`.
- Header "Company" dropdown works at desktop; mobile drawer works below
  1280px.
- Client-side routing confirmed: internal links change route without a page
  reload.
- All 55 distinct asset references and all 7 internal page links resolve to
  real files. The only unresolved links are the 10 not-yet-built routes in §3,
  which match the project's `status: "pending"` list exactly.

### Source repository

Source is **not** included in this package. The repository has one commit
(the `create-next-app` initial commit); all site work is uncommitted and
awaiting review. `CLAUDE.md` in the repo root is the authoritative project
document — read it before changing anything, particularly the rules on design
tokens, Figma being read-only, and never inventing client content.
